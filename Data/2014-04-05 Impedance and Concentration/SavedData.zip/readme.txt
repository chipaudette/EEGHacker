2014-04-05
WEA

Started with ECG electrodes configured as Forehead as Chan 1.  Same type of electrode behind left ear as ref and behind right ear as bias.

Then switched to gold cup electrode in identical arrangment.



2014-04-19

Gold cup electrode on left ear lobe as ref.  Tin clip electrode on right ear lobe as bias.  Chan 1 is gold cup on forehead (Left side).  Chan 2 is gold cup on O2.

Then moved Chan to to the forehead, right side.
